# Plugins

These are the individual plugins which display server data to the user in the UI.

Majority of the implementations of plugins are very simple since they leverage the Linux Dash core (`src/js/core/features`)

### disk-space

Shows the disk
